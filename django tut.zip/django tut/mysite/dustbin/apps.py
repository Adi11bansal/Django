from django.apps import AppConfig


class DustbinConfig(AppConfig):
    name = 'dustbin'
